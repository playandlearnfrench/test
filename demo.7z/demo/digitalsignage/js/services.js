'use strict';

/* Services */

var raspberryPiListServices = angular.module('raspberryPiListServices', ['ngResource']);	
  
  raspberryPiListServices.service('RaspberryPiService', function($http) {		
		this.list = function(){
			return $http({
					method: 'GET',
					dataType: "json",
					url: "http://localhost/demo/digitalsignage/raspberry.json"
				 }).then(function (response) {
					 // inspect/modify the received data and pass it onward
					 return response.data;
				 }, function (error) {					
					 throw error;
			});
		};

	});    