'use strict';

/* Controllers */

var homeControllers = angular.module('homeControllers', []);

homeControllers.controller('HomeController', function($scope, $http, RaspberryPiService) {
  $scope.message = 'Hello from HomeController';
  /*$scope.masterPi = [
      {name:'TV at 3rd floor', ipAddress:'176.6.23.95', isActive:1},
      {name:'TV at 10th floor', ipAddress:'176.6.81.150', isActive:0},
      {name:'TV at 14th floor', ipAddress:'176.6.20.91', isActive:1},
      ];
*/
  //$scope.masterPi = RaspberryPiService.getAllRaspberryPi();		
	RaspberryPiService.list().then(function (response) {			
		 $scope.masterPi = response.records;			 
	});    
});

homeControllers.controller('AssetController', function($scope) {
  $scope.message = 'Hello from AssetController';
});

homeControllers.controller('AboutController', function($scope) {
  $scope.message = 'Hello from AboutController';
});