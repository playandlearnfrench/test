var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider

  .when('/', {
    templateUrl : 'partials/home.html',
    controller  : 'HomeController'
  })

  .when('/addAsset', {
    templateUrl : 'partials/blog.html',
    controller  : 'AssetController'
  })

  .when('/about', {
    templateUrl : 'partials/about.html',
    controller  : 'AboutController'
  })

  .otherwise({redirectTo: '/'});
});

app.service('RaspberryPiService', function(){
            this.raspberries = function(a) {
               return PlayerService.getPlayer(a);
            }
         });

