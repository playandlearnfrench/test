'use strict';

/* App Module */

var teamListApp = angular.module('teamListApp', [
  'ngRoute',
  ,'teamCatControllers'  
  ,'teamListServices'
]);
    teamListApp.config(function ($routeProvider) {
        $routeProvider
            .when('/',
                {
                    controller: 'TeamListContoller',
                    templateUrl: 'partials/team-list.html'
                })            
            .when('/teamdesc/:id',
                {
                    controller: 'TeamDescController',
                    templateUrl: 'partials/team-detail.html'
                })
            .otherwise({ redirectTo: '/' });
    });