'use strict';

/* Controllers */

var teamCatControllers = angular.module('teamCatControllers', []);

	teamCatControllers.controller('TeamListContoller', function ($scope, $http, TeamService) {
		//$scope.teams = TeamService.getAllTeams();		
		TeamService.teams().then(function (response) {			
			 $scope.teams = response.records;			 
		 });		
	});

    teamCatControllers.controller('TeamDescController', function ($scope, $http, $routeParams, TeamService) {
		TeamService.getTeam($routeParams.id).then(function (response) {	
		  //$scope.team = TeamService.getteam($routeParams.id);
		   $scope.teamplayer=response.records;
		   console.log(response.records);
		});			    
    });