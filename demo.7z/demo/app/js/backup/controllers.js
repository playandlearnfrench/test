'use strict';

/* Controllers */

var teamListControllers = angular.module('teamListControllers', []);

teamListControllers.controller('TeamListCtrl', ['$scope', 'Team',
  function($scope, Team) {
    $scope.teams = Team.query();
    $scope.orderProp = 'name';
  }]);

teamListControllers.controller('TeamDetailCtrl', ['$scope', '$routeParams', 'Team',
  function($scope, $routeParams, Team) {
    $scope.team = Team.get({teamId: $routeParams.teamId}, function(team) {
      $scope.mainImageUrl = team.images[0];
    });

    $scope.setImage = function(imageUrl) {
      $scope.mainImageUrl = imageUrl;
    };
  }]);