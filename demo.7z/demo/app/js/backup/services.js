'use strict';

/* Services */

var teamListServices = angular.module('teamListServices', ['ngResource']);

teamListServices.factory('Team', ['$resource',
  function($resource){
    return $resource('teams/:teamId.json', {}, {
      query: {method:'GET', params:{teamId:'teams'}, isArray:true}
    });
  }]);