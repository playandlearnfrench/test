package com.sg.digitalsignage.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "assetsmaster")
public class AssetMaster {
	
	@Id
    @Column(name = "id")
	int id;
	
	String name;
	
	@Column(name = "ip_address", nullable=false)
	String ipAddress;
	 
	@Column(name = "is_enabled", nullable=false)
	boolean isEnabled;
	
	@Column(name = "login_id", nullable=false)
	String loginId;
	
	@Column(name = "login_pass", nullable=false)
	String loginPass;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getIpAdress() {
		return ipAddress;
	}

	public void setIpAdress(String ipAdress) {
		this.ipAddress = ipAdress;
	}
	
	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getLoginPass() {
		return loginPass;
	}

	public void setLoginPass(String loginPass) {
		this.loginPass = loginPass;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}	
	 
}