package com.sg.digitalsignage.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "assets")
public class Asset {

	@Id
    @Column(name = "asset_id")
    private String asset_id;
	private String name;
	private String uri;
	private String md5;
	
//	@Column(name = "start_date")
//	private Date start_date;
//	
//	@Column(name = "end_date")
//	private Date end_date;
	
	@Column(name = "start_date")
	private String start_date;
	@Column(name = "end_date")
	private String end_date;
	
	private String duration;
	@Column(name = "mimetype")
	private String mimetype;
	@Column(name = "is_enabled")
	private int is_enabled;
	@Column(name = "nocache")
	private int nocache;
	@Column(name = "play_order")
	private int play_order;
	
	private String ip_address;
	
	private Boolean is_active;
	
	public String getAsset_id() {
		return asset_id;
	}
	public void setAsset_id(String assetId) {
		this.asset_id = assetId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getMd5() {
		return md5;
	}
	public void setMd5(String md5) {
		this.md5 = md5;
	}
//	public Date getStart_date() {
//		return start_date;
//	}
//	public void setStart_date(Date startDate) {
//		this.start_date = startDate;
//	}
//	public Date getEnd_date() {
//		return end_date;
//	}
//	public void setEnd_date(Date endDate) {
//		this.end_date = endDate;
//	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimeType) {
		this.mimetype = mimeType;
	}
	public int getIs_enabled() {
		return is_enabled;
	}
	public void setIs_enabled(int isEnabled) {
		this.is_enabled = isEnabled;
	}
	public int getNocache() {
		return nocache;
	}
	public void setNocache(int noCache) {
		this.nocache = noCache;
	}
	public int getPlay_order() {
		return play_order;
	}
	public void setPlay_order(int playOrder) {
		this.play_order = playOrder;
	}
	public String getIp_address() {
		return ip_address;
	}
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}
	public Boolean getIs_active() {
		return is_active;
	}
	public void setIs_active(Boolean is_active) {
		this.is_active = is_active;
	}
    
}
