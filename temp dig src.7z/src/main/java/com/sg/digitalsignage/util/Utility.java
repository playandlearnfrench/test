package com.sg.digitalsignage.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Utility {
	
	public static final TimeZone utcTZ = TimeZone.getTimeZone("UTC");
	 
    public static long toLocalTime(long time, TimeZone to) {
        return convertTime(time, utcTZ, to);
    }
 
    public static long toUTC(long time, TimeZone from) {
        return convertTime(time, from, utcTZ);
    }
 
    public static long convertTime(long time, TimeZone from, TimeZone to) {
        return time + getTimeZoneOffset(time, from, to);
    }
 
    private static long getTimeZoneOffset(long time, TimeZone from, TimeZone to) {
        int fromOffset = from.getOffset(time);
        int toOffset = to.getOffset(time);
        int diff = 0;
 
        if (fromOffset >= 0){
            if (toOffset > 0){
                toOffset = -1*toOffset;
            } else {
                toOffset = Math.abs(toOffset);
            }
            diff = (fromOffset+toOffset)*-1;
        } else {
            if (toOffset <= 0){
                toOffset = -1*Math.abs(toOffset);
            }
            diff = (Math.abs(fromOffset)+toOffset);
        }
        return diff;
    }
    
    public static String convertDateForDbSave(String dateInString){
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.000Z'");
			Date date = inputFormat.parse(dateInString);			
        	SimpleDateFormat outPutFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        	return outPutFormat.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
			return dateInString;
		}
	}
	
    public static java.util.Date toDate(java.sql.Timestamp timestamp) {
	    long milliseconds = timestamp.getTime() + (timestamp.getNanos() / 1000000);
	    return new java.util.Date(milliseconds);
	}
}
