package com.sg.digitalsignage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sg.digitalsignage.dao.AssetMasterDao;
import com.sg.digitalsignage.model.AssetMaster;

@Service("assetMasterService")
public class AssetMasterServiceImpl implements AssetMasterService {
	
	@Autowired
	AssetMasterDao assetMasterDao;
	
	public List<AssetMaster> getAssetMaster() {
		List<AssetMaster> assetMasters = assetMasterDao.getAllAssetMasters();
		return assetMasters;
	}

	@Override
	public AssetMaster findById(String assetIp, String asset_id) {
		return assetMasterDao.findById(assetIp, asset_id);
	}

	@Override
	public void updateAssetMaster(AssetMaster currentAssetMaster) {
		assetMasterDao.updateAssetMaster(currentAssetMaster);
	}
	
	@Override
	public void addAssetMaster(AssetMaster assetMaster) {
		assetMasterDao.addAssetMaster(assetMaster);		
	}

}
