package com.sg.digitalsignage.service;

import java.util.List;

import com.sg.digitalsignage.model.AssetMaster;

public interface AssetMasterService {
	List<AssetMaster> getAssetMaster();
	AssetMaster findById(String assetIp, String assetId);
	void updateAssetMaster(AssetMaster currentAssetMaster);
	void addAssetMaster(AssetMaster assetMaster);
}
