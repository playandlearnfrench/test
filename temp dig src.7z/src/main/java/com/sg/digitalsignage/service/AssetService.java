package com.sg.digitalsignage.service;

import java.util.List;

import com.sg.digitalsignage.model.Asset;

public interface AssetService {
	List<Asset> getAssets();
	Asset findById(String assetIp, String assetId);
	void updateAsset(Asset currentAsset);
	//void updateOrder(Asset asset);
	void updateOrder(String ipAddress, String assetIds);
	void deleteUserById(String assetIp, String assetId);
	void addAsset(Asset asset);
	void addAssets(List<Asset> assets);
	List<Asset> getAssetByIp(String assetIp);
}
