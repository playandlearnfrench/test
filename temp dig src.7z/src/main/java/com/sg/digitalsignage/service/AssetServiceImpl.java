package com.sg.digitalsignage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sg.digitalsignage.dao.AssetDao;
import com.sg.digitalsignage.model.Asset;

@Service("assetService")
public class AssetServiceImpl implements AssetService {
	
	@Autowired
	AssetDao assetDao;
	
	public List<Asset> getAssets() {
		List<Asset> assets = assetDao.getAllAssets();
		return assets;
	}
	
	public List<Asset> getAssetByIp(String assetIp) {
		return assetDao.getAssetByIp(assetIp);		
	}

	@Override
	public Asset findById(String assetIp, String asset_id) {
		return assetDao.findById(assetIp, asset_id);
	}

	@Override
	public void updateAsset(Asset currentAsset) {
		assetDao.updateAsset(currentAsset);
	}

	@Override
	public void updateOrder(String ipAddress,String assetIds) {
		String [] arrAssets = assetIds.split(",");
		//List<String> asstIds = new ArrayList<String>(Arrays.asList(assetIds.split(",")));
		int playOrder=0;
		for(String assetId : arrAssets ){
			Asset asset=new Asset();
			asset.setIp_address(ipAddress);
			asset.setAsset_id(assetId);
			asset.setPlay_order(playOrder);
			assetDao.updateOrder(asset);
			playOrder++;
		}
	}

	@Override
	public void deleteUserById(String assetIp, String assetId) {
		assetDao.deleteAsset(assetIp, assetId);		
	}

	@Override
	public void addAsset(Asset asset) {
		assetDao.addAsset(asset);		
	}

	@Override
	public void addAssets(List<Asset> assets) {
		assetDao.addAssets(assets);		
	}

}
