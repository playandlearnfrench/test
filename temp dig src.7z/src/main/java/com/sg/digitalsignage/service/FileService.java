package com.sg.digitalsignage.service;

import java.util.List;
import javax.servlet.http.HttpSession;

public interface FileService {
	boolean startFTPUpload(String fileToFTP, HttpSession session, List<String> ipAddress);
	void startFTPUploadDb(String fileToFTP, HttpSession session, List<String> ipAddress);
	boolean startFTPDelete(String fileToFTP, HttpSession session);
}
