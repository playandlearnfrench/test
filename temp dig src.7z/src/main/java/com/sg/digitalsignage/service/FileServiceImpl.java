package com.sg.digitalsignage.service;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.sg.digitalsignage.model.AssetMaster;

@Component
@Scope(value="session", proxyMode=ScopedProxyMode.TARGET_CLASS)
public class FileServiceImpl implements FileService {
	static Properties props;
	
	@Autowired
	private Environment env;	
	
	public boolean startFTPUpload(String fileToFTP, HttpSession session, List<String> ipAddress){
		  String remoteDirectory = env.getProperty("remoteDirectory");
		  String localDirectory = env.getProperty("localDirectory");
		  return ftpUpload(fileToFTP, session, remoteDirectory, localDirectory, ipAddress);
	}
	
	public void startFTPUploadDb(String fileToFTP, HttpSession session, List<String> ipAddress){		 
		  String remoteDbDirectory = env.getProperty("remoteDbDirectory");
		  String localDbDirectory = env.getProperty("localDbDirectory");
		  ftpUpload(fileToFTP, session, remoteDbDirectory, localDbDirectory, ipAddress);
	}
	
	private boolean ftpUpload(String fileToFTP, HttpSession session, String remoteDbDirectory, String localDbDirectory, 
			List<String> ipAddress) {
		StandardFileSystemManager manager = new StandardFileSystemManager();
		boolean ftpUploadStatus = true;
		//List<AssetsMasterTable> listRaspberryPi = (List<AssetsMasterTable>) session.getAttribute("assetsMaster");
		Map<String, AssetMaster> mapIpAddress = (Map<String, AssetMaster>) session.getAttribute("mapIpAddress");		
		for (String tmpIpAddress: ipAddress){
			try {				
				//String serverAddress = mapIpAddress.get(tmpIpAddress).getIpAddress();
				String serverAddress = tmpIpAddress;
				String userId = mapIpAddress.get(tmpIpAddress).getLoginId();
				String password = mapIpAddress.get(tmpIpAddress).getLoginPass();
				
				String filepath = localDbDirectory + File.separator +  fileToFTP;
				File file = new File(filepath);
				if (!file.exists()){
					throw new RuntimeException("Error. Local file not found");
				}				  
				manager.init();				  
				FileSystemOptions opts = new FileSystemOptions();
				SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
				SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
				SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);
				
				String sftpUri = "sftp://" + userId + ":" + password +  "@" + serverAddress + "/" + remoteDbDirectory + "/" + fileToFTP;
				
				FileObject localFile = manager.resolveFile(file.getAbsolutePath());				  
				FileObject remoteFile = manager.resolveFile(sftpUri, opts);
				
				remoteFile.copyFrom(localFile, Selectors.SELECT_SELF);				  
			}
			catch (Exception ex) {				  
				ftpUploadStatus = false;
				ex.printStackTrace();
			}
			finally {
				manager.close();
			}
			
		}
	    
		return ftpUploadStatus;
	}
	
	public boolean startFTPDelete(String fileToFTP, HttpSession session){
		//  props = new Properties();
		  StandardFileSystemManager manager = new StandardFileSystemManager();
		
		  try {		
			   
			   String serverAddress = env.getProperty("serverAddress");
			   String userId = env.getProperty("userId");
			   String password = env.getProperty("password");
			   String remoteDirectory = env.getProperty("remoteDirectory");
		
			   manager.init();
			   
			   FileSystemOptions opts = new FileSystemOptions();
			   SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
			   SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
			   SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);
			   String sftpUri = "sftp://" + userId + ":" + password +  "@" + serverAddress + "/" + remoteDirectory + "/" + fileToFTP;
			   
			   FileObject remoteFile = manager.resolveFile(sftpUri, opts);

			   //Check if the file exists
			   if(remoteFile.exists()){
				   remoteFile.delete();
				   System.out.println("File delete successful");
			   }
		  }
		  catch (Exception ex) {
			  ex.printStackTrace();
			  return false;
		  }
		  finally {
			  manager.close();
		  }
		return true;
	}

}
