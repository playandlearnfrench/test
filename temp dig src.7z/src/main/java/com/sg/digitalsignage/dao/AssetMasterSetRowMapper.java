package com.sg.digitalsignage.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.sg.digitalsignage.model.AssetMaster;

public class AssetMasterSetRowMapper implements RowMapper<Object> {
	
	public Object mapRow(ResultSet rs, int rownum) throws SQLException {
		AssetMaster assetMaster = new AssetMaster();
		assetMaster.setId(rs.getInt("id"));
		assetMaster.setName(rs.getString("name"));
		assetMaster.setLoginId(rs.getString("login_id"));
		assetMaster.setLoginPass(rs.getString("login_pass"));
		assetMaster.setEnabled(rs.getBoolean("is_enabled"));
		assetMaster.setIpAddress(rs.getString("ip_address"));		
		return assetMaster;
	}
	
}
