package com.sg.digitalsignage.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sg.digitalsignage.model.AssetMaster;

@Repository
@Transactional(readOnly = true)
public class AssetMasterDaoImpl implements AssetMasterDao{

	private static final Logger LOGGER = Logger.getLogger(AssetMasterDaoImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<AssetMaster> getAllAssetMasters() {
		LOGGER.info("getAllAssetMasters !!");
		List<AssetMaster> assetMasters = new ArrayList<AssetMaster>();
		try
		   {
			String selectSQL="select * from assetsmaster order by ip_address";

			List<Object> rows = jdbcTemplate.query(selectSQL, new Object[] { }, new AssetMasterSetRowMapper());
			Iterator<Object> itrList=rows.iterator();
			while(itrList.hasNext()){
				AssetMaster assetMaster=(AssetMaster) itrList.next();
				assetMasters.add(assetMaster);
		    }
		  } catch (Exception e){
			  LOGGER.info("Exception in getAllAssetMasters!!");
			  e.printStackTrace();
		   }
		return assetMasters;
	}

	@Override
	public AssetMaster findById(String assetIp, String assetId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateAssetMaster(AssetMaster currentAssetMaster) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void deleteAssetMaster(String assetIp, String assetId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addAssetMaster(AssetMaster assetMaster) {
		// TODO Auto-generated method stub
		
	}

}
