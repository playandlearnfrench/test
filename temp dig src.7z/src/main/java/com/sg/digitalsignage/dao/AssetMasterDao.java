package com.sg.digitalsignage.dao;

import java.util.List;

import com.sg.digitalsignage.model.AssetMaster;

public interface AssetMasterDao {
	List<AssetMaster> getAllAssetMasters();

	AssetMaster findById(String assetIp, String assetId);

	void updateAssetMaster(AssetMaster currentAssetMaster);

	void deleteAssetMaster(String assetIp, String assetId);

	void addAssetMaster(AssetMaster assetMaster);
}
