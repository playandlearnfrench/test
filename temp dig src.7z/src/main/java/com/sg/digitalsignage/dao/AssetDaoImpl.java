package com.sg.digitalsignage.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.cxf.common.util.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sg.digitalsignage.controller.AssetRestController;
import com.sg.digitalsignage.model.Asset;
import com.sg.digitalsignage.util.Utility;

@Repository
@Transactional(readOnly = true)
public class AssetDaoImpl implements AssetDao {
	
	private static final Logger LOGGER = Logger.getLogger(AssetDaoImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Asset> getAllAssets() {
		List<Asset> assets = new ArrayList<Asset>();
		try
		   {
			String assetIp="176.6.23.95"; //should get from session
			String selectSQL="select * from assets where ip_address=? order by play_order";
//			String selectSQL = "select asset_id,name,uri,md5,datetime(start_date,'localtime') as start_date"
//					+ ",datetime(end_date,'localtime') as end_date,"
//					+ "duration,mimetype,is_enabled,"
//					+ "nocache, play_order,ip_address from assets where ip_address=?";

			List<Object> rows = jdbcTemplate.query(selectSQL, new Object[] { assetIp }, new AssetSetRowMapper());
			Iterator<Object> itrList=rows.iterator();
			
//			List<Asset> rows  = jdbcTemplate.query(selectSQL,new BeanPropertyRowMapper(Asset.class));
//			Iterator<Asset> itrList=rows.iterator();
			
			while(itrList.hasNext()){
				 Asset asset=(Asset) itrList.next();
			     
			     //System.out.println(" "+asset.getAsset_id()+"\t "+ asset.getName()+"\t "+asset.getStart_date());
			     assets.add(asset);
		    }
		  } catch (Exception e){
			  	e.printStackTrace();
		   }
		return assets;
	}
	
	public List<Asset> getAssetByIp(String assetIp) {
		List<Asset> assets = new ArrayList<Asset>();
		try
		   {
				String selectSQL="select * from assets where ip_address=? order by play_order";
	
				List<Object> rows = jdbcTemplate.query(selectSQL, new Object[] { assetIp }, new AssetSetRowMapper());
				Iterator<Object> itrList=rows.iterator();
				
				while(itrList.hasNext()){
					 Asset asset=(Asset) itrList.next();			     
				     assets.add(asset);
			    }
			} catch (Exception e){
			  	e.printStackTrace();
		    }
		return assets;
	}

	@Override
	public Asset findById(String assetIp, String asset_id) {
		Asset asset = null;
		try
		   {
			//String assetIp="176.6.23.95";
			String selectSQL="select * from assets where ip_address=? AND asset_id=?";

			List<Object> rows = jdbcTemplate.query(selectSQL, new Object[] { assetIp,asset_id }, new AssetSetRowMapper());
			Iterator<Object> itrList=rows.iterator();
			
			while(itrList.hasNext()){
				 asset=(Asset) itrList.next();
			    // System.out.println(" "+asset.getAsset_id()+"\t "+ asset.getName()+"\t "+asset.getStart_date());
		    }
		  } catch (Exception e){
			  	e.printStackTrace();
		   }
		return asset;
	}

	@Override
	public void updateAsset(Asset asset) {
		try
		   {
			String sql="update assets set name=?, start_date=?, end_date=?, duration=?,is_enabled=? where ip_address=? AND asset_id=?";
			//jdbcTemplate.update(sql, asset.getIs_enabled(), asset.getIp_address(), asset.getAsset_id());
			jdbcTemplate.update(sql, new Object[] { 
					asset.getName(),
					convertDateForSave(asset.getStart_date()),
					convertDateForSave(asset.getEnd_date()),
					asset.getDuration(),
					asset.getIs_enabled(),
					asset.getIp_address(),
					asset.getAsset_id()
				}
			);
		    
		  } catch (Exception e){
			  	e.printStackTrace();
		   }		
	}
	
	private String convertDateForSave(String dateInString){
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			SimpleDateFormat outPutFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = inputFormat.parse(dateInString);			
        	return outPutFormat.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
			return dateInString;
		}
	}

	@Override
	public void updateOrder(Asset asset) {
		String sql="update assets set play_order=? where ip_address=? AND asset_id=?";
		jdbcTemplate.update(sql, new Object[] { 
				asset.getPlay_order(),				
				asset.getIp_address(),
				asset.getAsset_id()
			}
		);
		
	}

	@Override
	public void deleteAsset(String assetIp, String assetId) {
		String sql="delete from assets where ip_address=? AND asset_id=?";
		jdbcTemplate.update(sql, new Object[] { 
				assetIp,				
				assetId
			}
		);
	}

	@Override
	public void addAsset(Asset asset) {
		LOGGER.info("Add Asset Data !!");
		String sql="insert into assets (asset_id, name, uri, start_date, end_date "
				+ ", duration, mimetype, is_enabled, play_order, ip_address) "
				+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
		//jdbcTemplate.update(sql, asset.getIs_enabled(), asset.getIp_address(), asset.getAsset_id());
		try {
			int recordCount = jdbcTemplate.update(sql, new Object[] {
					asset.getAsset_id(),
					asset.getName(),
					asset.getUri(),
					Utility.convertDateForDbSave(asset.getStart_date()),
					Utility.convertDateForDbSave(asset.getEnd_date()),
					asset.getDuration(),
					asset.getMimetype(),
					asset.getIs_enabled(),
					asset.getPlay_order(),
					asset.getIp_address()
				}
			);
			LOGGER.info("Inserted "+ recordCount);
		} catch (DataAccessException ex) {
			ex.printStackTrace();
		}
		
	}

	@Override
	public void addAssets(List<Asset> assetList) {
		LOGGER.info("Add multiple assets !!");
		//boolean returnStatus=true;
		String insertSql = "INSERT INTO assets(asset_id,name,uri,start_date,end_date,duration,mimetype,is_enabled,ip_address) VALUES ";
		String values="";
		for(Asset asset:assetList){
			String urlTemp = "/home/pi/screenly_assets/"+asset.getAsset_id();
			
			String start_date = asset.getStart_date().toString();
			start_date = removeLastTwoCharacter(start_date);
			
			String end_date = asset.getEnd_date().toString();
			end_date = removeLastTwoCharacter(end_date);
			if(StringUtils.isEmpty(values)){
				values = "('"								
						+ asset.getAsset_id() + "','"+ asset.getName()+ "','"+ urlTemp+ "',datetime('"+start_date+"','utc')"
						+ ",datetime('"+end_date+"','utc'),'" + asset.getDuration() + "','" + asset.getMimetype()+ "',0,'"	+ asset.getIp_address() + "')";
			}else{
				values += ",('"								
						+ asset.getAsset_id() + "','"+ asset.getName()+ "','"+ urlTemp+ "',datetime('"+start_date+"','utc')"
						+ ",datetime('"+end_date+"','utc'),'" + asset.getDuration() + "','" + asset.getMimetype()+ "',0,'"	+ asset.getIp_address() + "')";	
			}
		}
		insertSql +=values;
		try {
			Object[] params = new Object[] { };			
			int[] types = new int[] { };			
			int row = jdbcTemplate.update(insertSql, params, types);
			if( row > 0 ) {
				//returnStatus= true;
				System.out.println(row + " row inserted.");
			}
		}catch (Exception e) {
			e.printStackTrace();
			//returnStatus= false;
		}		
		//return returnStatus;		
	}
	private String removeLastTwoCharacter(String start_date) {
		if (start_date.endsWith(".0")) {
			start_date = start_date.substring(0, start_date.length() - 2);
		}
		return start_date;
	}

}
