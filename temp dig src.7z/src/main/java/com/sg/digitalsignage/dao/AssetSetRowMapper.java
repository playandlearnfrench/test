package com.sg.digitalsignage.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.sg.digitalsignage.model.Asset;

public class AssetSetRowMapper implements RowMapper<Object> {
	
	public Object mapRow(ResultSet rs, int rownum) throws SQLException {
		Asset asset = new Asset();
		asset.setAsset_id(rs.getString("asset_id"));
		asset.setName(rs.getString("name"));
		asset.setUri(rs.getString("uri"));
		asset.setMd5(rs.getString("md5"));
		asset.setDuration(rs.getString("duration"));
		asset.setMimetype(rs.getString("mimetype"));
		//asset.setStart_date(rs.getDate("start_date"));
		//asset.setEnd_date(rs.getDate("end_date"));
		//asset.setStart_date(rs.getString("start_date"));
		//asset.setEnd_date(rs.getString("end_date"));
		asset.setStart_date(convertDate(rs.getString("start_date")));
	    asset.setEnd_date(convertDate(rs.getString("end_date")));
		  
		asset.setIs_enabled(rs.getInt("is_enabled"));
		asset.setNocache(rs.getInt("nocache"));
		asset.setPlay_order(rs.getInt("play_order"));
		asset.setIp_address(rs.getString("ip_address"));
		asset.setIs_active(true);
		
		SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date date =null;
		try {
			date = inFormat.parse(asset.getEnd_date());
			if(date.before(new java.util.Date())){
				asset.setIs_active(false);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return asset;
	}
	private String convertDate(String dateInString){
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = inputFormat.parse(dateInString);			
        	SimpleDateFormat outPutFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        	return outPutFormat.format(date);
		} catch (Exception ex) {
			ex.printStackTrace();
			return dateInString;
		}
	}
}
