package com.sg.digitalsignage.dao;

import java.util.List;

import com.sg.digitalsignage.model.Asset;

public interface AssetDao {
	List<Asset> getAllAssets();

	Asset findById(String assetIp, String assetId);

	void updateAsset(Asset currentAsset);

	void updateOrder(Asset asset);

	void deleteAsset(String assetIp, String assetId);

	void addAsset(Asset asset);
	
	void addAssets(List<Asset> assets);
	
	List<Asset> getAssetByIp(String assetIp);
}
