package com.sg.digitalsignage.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sg.digitalsignage.model.Asset;
import com.sg.digitalsignage.model.AssetMaster;
import com.sg.digitalsignage.service.AssetMasterService;
import com.sg.digitalsignage.service.AssetService;
import com.sg.digitalsignage.service.FileService;

@RestController
@RequestMapping("/")
@PropertySource({	
	"classpath:application.properties",
	"classpath:config.properties" //if same key, this will 'override'
})
@SessionAttributes(value = {"assetMasters","mapIpAddress"}, types = {AssetMaster.class})
public class AssetRestController {
	
	private static final Logger LOGGER = Logger.getLogger(AssetRestController.class);
	
	@Autowired
	AssetService assetService;	
	@Autowired
	AssetMasterService assetMasterService;
	
	@Autowired
	Environment env;
	
	@Autowired
	FileService fileService;

	private static Map<String, AssetMaster> mapIpAddress = new HashMap<String, AssetMaster>();
	
	//-------------------Retrieve All Raspberry Pi--------------------------------------------------------
	@RequestMapping(value = "/raspBerryPi", method = RequestMethod.GET)
	public ResponseEntity<List<AssetMaster>>  getRaspBerryPi() {
		LOGGER.info("Getting all Raspberry Pi Information !!");
		
		List<AssetMaster> assetMasters = assetMasterService.getAssetMaster();
		if(assetMasters.isEmpty()){
			return new ResponseEntity<List<AssetMaster>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<AssetMaster>>(assetMasters,HttpStatus.OK);
	}
		
	//-------------------Retrieve All Assets--------------------------------------------------------
	@RequestMapping(value = "/assets", method = RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object>  getAssets(HttpServletRequest request, HttpSession session) {
		LOGGER.info("Getting all Asset Data !!");
		String ipAddress = request.getParameter("ipAddress");
		//ModelAndView modelView = new ModelAndView("home");
		ModelAndView modelView = new ModelAndView("master");
		//List<Asset> assets = assetService.getAssets();
		List<Asset> assets = assetService.getAssetByIp(ipAddress);
		//List<JSONObject> entities = new ArrayList<JSONObject>();
		session.setMaxInactiveInterval(3600);
		if(StringUtils.isEmpty(session.getAttribute("assetMasters"))){
			List<AssetMaster> listRaspberryPi = assetMasterService.getAssetMaster();
			for (AssetMaster assetMaster :  listRaspberryPi) {
				mapIpAddress.put(assetMaster.getIpAddress(), assetMaster);
			}
			modelView.addObject("assetMasters", listRaspberryPi);
			modelView.addObject("mapIpAddress", mapIpAddress);			
        }
		
		if(assets.isEmpty()){
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<Object>(assets,HttpStatus.OK);
	}
	
	//-------------------Retrieve Assets for a particular IpAddress---------------------------------------
		@RequestMapping(value = "/assets/{ip}", method = RequestMethod.GET)
		public ResponseEntity<List<Asset>> getAsset(@PathVariable("ip") String assetIp, HttpServletRequest request, HttpSession session) {
			LOGGER.info("Getting all Asset Data for IP "+assetIp+" !!");
			ModelAndView modelView = new ModelAndView("master");
			List<Asset> assets = assetService.getAssetByIp(assetIp);
			modelView.addObject("assets", assets);
			if(assets.isEmpty()){
				return new ResponseEntity<List<Asset>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
			}
			return new ResponseEntity<List<Asset>>(assets,HttpStatus.OK);
		}
		
	
	//------------------- Update a asset --------------------------------------------------------
    @RequestMapping(value = "/assets/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Asset> updateAsset(@PathVariable("id") String assetId, HttpServletRequest request,
    		@RequestBody String model) throws UnsupportedEncodingException {
    	LOGGER.info("Editing asset Data !!");
        String assetIp="176.6.23.95";
        Asset currentAsset = assetService.findById(assetIp, assetId);
         
        if (currentAsset==null) {
            return new ResponseEntity<Asset>(HttpStatus.NOT_FOUND);
        }
        
        String result=java.net.URLDecoder.decode(model, "UTF-8");
        String [] jsonAssets = result.split("=");
        Asset asset = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
			asset = mapper.readValue(java.net.URLDecoder.decode(jsonAssets[1], "UTF-8"), Asset.class);
			assetService.updateAsset(asset);
			currentAsset = asset;
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return new ResponseEntity<Asset>(currentAsset, HttpStatus.OK);
    }
	
    @RequestMapping(value = "/assets/order", method = RequestMethod.POST)
    public ResponseEntity<Asset> updateOrder(@RequestBody String ids) throws UnsupportedEncodingException {
    	LOGGER.info("Updating Asset order !!");
		String assetIp="176.6.23.95";
        String result=java.net.URLDecoder.decode(ids, "UTF-8");
        String [] jsonAssets = result.split("=");
        assetService.updateOrder(assetIp,jsonAssets[1]);
        return new ResponseEntity<Asset>(new Asset(), HttpStatus.OK);
    }
	
	@RequestMapping(value = "/assets/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Asset> deleteAsset(@PathVariable("id") String assetId)  {
		LOGGER.info("Deleting Asset Data!!");
		String assetIp="176.6.23.95";
        Asset currentAsset = assetService.findById(assetIp, assetId);
         
        if (currentAsset==null) {
            LOGGER.info("Unable to delete Asset " + assetId );
            return new ResponseEntity<Asset>(HttpStatus.NOT_FOUND);
        }
        assetService.deleteUserById(assetIp,assetId);
        return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
    }
	
	@RequestMapping(value = "/assets", method = RequestMethod.OPTIONS)
    public ResponseEntity<Asset> addAsset()  {
        return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
    }
	
	@RequestMapping(value = "/assets", method = RequestMethod.POST)
	public ResponseEntity<Asset> addAssets(MultipartHttpServletRequest request, HttpServletResponse response, HttpSession session) {
		LOGGER.info("Add new Asset Data!!");
		//Asset asset=new Asset();
    	
    	Iterator<String> itr =  request.getFileNames();	    	 
        MultipartFile file = request.getFile(itr.next());
        
        String assetId= UUID.randomUUID().toString().replaceAll("-", "").trim();
        
        String assetUriPath = env.getProperty("assetUri").trim();
        
//        asset.setAsset_id(assetId);
//        asset.setUri(assetUriPath + "/" + assetId);        
//        asset.setName(request.getParameter("name"));
//		asset.setMimetype(request.getParameter("mimetype"));
//		asset.setDuration(request.getParameter("duration"));
//		asset.setIs_enabled(0);
//		asset.setStart_date(request.getParameter("start_date"));
//		asset.setEnd_date(request.getParameter("end_date"));
//		String ipAddress="176.6.23.95";
//		asset.setIp_address(ipAddress);
      
        String selectedIpAddress = request.getParameter("selectedIpAddress");
		
    	if (!file.isEmpty()) {
            try {
            	String fileName = file.getOriginalFilename();
                byte[] bytes = file.getBytes();
                File dir = new File(env.getProperty("localDirectory").trim());
                if (!dir.exists())
                    dir.mkdirs();
                // Create the file on server
                File serverFile = new File(dir.getAbsolutePath() + File.separator + assetId);
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();
                List<String> ipAddressList = Arrays.asList(selectedIpAddress.split(","));                
                List<Asset> assetList = new ArrayList<Asset>();
                
               // if(fileService.startFTPUpload(assetId, session, ipAddressList)){
                	
                	for (String tmpIpAddress: ipAddressList){
                		Asset asset=new Asset();
                		asset.setAsset_id(assetId);
                		asset.setName(request.getParameter("name"));
                		asset.setDuration(request.getParameter("duration"));
                		asset.setMimetype(request.getParameter("mimetype"));		                
                		
                		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
                		String start_date = request.getParameter("start_date");
                		asset.setStart_date(start_date);
                		
						/*Date parsedTimeStamp = formatter.parse(start_date );                		
                		Timestamp timestamp = new Timestamp(parsedTimeStamp.getTime());
                		asset.setStart_date(timestamp);*/
                		String end_date = request.getParameter("end_date");
                		asset.setEnd_date(end_date);
                		/*
						Date parsedTimeStamp1 = formatter.parse(end_date);                		
                		Timestamp timestamp1 = new Timestamp(parsedTimeStamp1.getTime());
                		asset.setEnd_date(timestamp1);
                		*/
                		asset.setIp_address(tmpIpAddress);
                		
                		assetList.add(asset);
                	}
                	assetService.addAssets(assetList);
               // }
                LOGGER.info("You have successfully uploaded " + fileName);
               // assetService.addAsset(asset);
                return new ResponseEntity<Asset>(assetList.get(0),HttpStatus.OK);
            } catch (Exception e) {
            	LOGGER.info("Failed to upload file " + e.getMessage());
                return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
            }
        } else {
        	LOGGER.info("Unable to upload. File is empty !!");
            return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
        }    	
	}
	
}
