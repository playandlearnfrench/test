package com.sg.digitalsignage.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
//import org.jboss.logging.Logger;
import org.springframework.web.servlet.ModelAndView;

import com.sg.digitalsignage.model.AssetMaster;
import com.sg.digitalsignage.service.AssetMasterService;
import com.sg.digitalsignage.service.AssetService;

@Controller
@SessionAttributes(value = {"assetsMaster","mapIpAddress"}, types = {AssetMaster.class})
public class AssetMasterController {
	
	@Autowired
	AssetService assetService;
	
	@Autowired
	AssetMasterService assetMasterService;
	
	private static final Logger LOGGER = Logger.getLogger(AssetMasterController.class);
	
	private static Map<String, AssetMaster> mapIpAddress = new HashMap<String, AssetMaster>();
	
	@RequestMapping(value="/master")
    public ModelAndView master(HttpSession session, @CookieValue("JSESSIONID") String cookie) {
		LOGGER.info("Assets Master home !!");
        ModelAndView model = new ModelAndView("master");
        model.addObject("name", "Digital Signage");        
        if(StringUtils.isEmpty(session.getAttribute("assetsMaster"))){
			List<AssetMaster> listRaspberryPi = assetMasterService.getAssetMaster();
			for (AssetMaster assetMaster :  listRaspberryPi) {
				mapIpAddress.put(assetMaster.getIpAddress(), assetMaster);
			}
			model.addObject("assetsMaster", listRaspberryPi);
			model.addObject("mapIpAddress", mapIpAddress);			
        }
        return model;
    }
	
	@RequestMapping(value="/home")
    public ModelAndView home(HttpServletRequest request, HttpSession session) {
		LOGGER.info("Assets home !!");
		String ipAddress = request.getParameter("ipAddress");
        ModelAndView model = new ModelAndView("home");
        model.addObject("name", "Digital Signage");
        if(StringUtils.isEmpty(session.getAttribute("assetMasters"))){
        	model.addObject("assetMasters", assetMasterService.getAssetMaster());
        	//session.getAttribute("assetMasters");
        }
        return model;
    }
	@RequestMapping(value="/index")
    public ModelAndView index(HttpSession session, @CookieValue("JSESSIONID") String cookie) {
		LOGGER.info("Assets default index !!");
        ModelAndView model = new ModelAndView("index");
        model.addObject("name", "Digital Signage");
        if(StringUtils.isEmpty(session.getAttribute("assetMasters"))){        		
        	model.addObject("assetMasters", assetMasterService.getAssetMaster());
        }
        return model;
    }
	
}
