import React from "react";
import axios from "axios";
import { Document, Page } from "react-pdf";
class About extends React.Component {
  constructor(props) {
    super(props);
    this.objRef = React.createRef();
    this.state = { data: "" };
  }
  state = {
    data: "",
  };
  componentDidMount() {
    this.handleClick("first");
  }
  componentDidUpdate(prevState, prevProps) {
    // react to update and change the HTML element's size
    // this.objRef.current.style.width = `${this.state.size}px`;
    //this.objRef.current.style.height = `${this.state.size}px`;
    if (prevProps.url !== this.props.url) {
      this.handleClick();
    }
  }
  handleClick(str) {
    // console.log("this is:", this);
    // console.log("str is:", str);
    //let url='http://www.africau.edu/images/default/sample.pdf';
    let url = "http://localhost/demo/testpdf.php?fileName=" + str;
    // if(str==='second'){
    // url='http://localhost/';
    //}
    //const config = { responseType: "blob" };
    axios
      .get(url, {
        responseType: "blob",
      })
      .then((response) => {
        //console.log("success");
        // response.data is an empty object
        const blob = new Blob([response.data], {
          type: "application/pdf",
        });
        //FileSaver.saveAs(blob, 'file.pdf');
        // this.setDate({ data: blob });
        // const blob = new Blob([response.data]);
        const url = window.URL.createObjectURL(blob);
        //FileSaver.saveAs(blob, str + ".pdf");
        this.setState({ data: url });
        /*const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", str + ".pdf");
        document.body.appendChild(link);
        link.click();*/
      })
      .catch((error) => {
        console.log(error.response);
      });
  }
  render() {
    return (
      <div>
        <h1>About...</h1>
        <button onClick={() => this.handleClick("first")}>First</button>
        <button onClick={() => this.handleClick("second")}>Second</button>
        <object
          ref={this.objRef}
          width="100%"
          height="400"
          data={this.state.data}
          type="application/pdf"
        >
          {" "}
        </object>
      </div>
    );
  }
}
export default About;
