import React, { Component } from 'react';
import StoreLocator from './StoreLocator';
import '../App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <StoreLocator />
      </div>
    );
  }
}

export default App;
