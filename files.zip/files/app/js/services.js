'use strict';

/* Services */

var teamListServices = angular.module('teamListServices', ['ngResource']);
	
	/*teamListServices.factory('TeamService', ['$resource',
	  function($resource){
		return $resource('teams/:teamId.json', {}, {
		  query: {method:'GET', params:{teamId:'teams'}, isArray:true}
		});
	}]);*/
  
  teamListServices.service('TeamService', function($http) {		
		this.teams = function(){
			return $http({
					method: 'GET',
					dataType: "json",
					url: "http://localhost/ZendFrameworkQuickstart/public/team/"
				 }).then(function (response) {
					 // inspect/modify the received data and pass it onward
					 return response.data;
				 }, function (error) {					
					 throw error;
			});
		};		
		this.getTeam = function(id){
			return $http({
					method: 'GET',
					dataType: "json",
					url: "http://localhost/ZendFrameworkQuickstart/public/team/"+id				
				 }).then(function (response) {
					 // inspect/modify the received data and pass it onward
					 return response.data;
				 }, function (error) {					
					 throw error;
			})
		};		
	});    