<?php

/**
 * Created by PhpStorm.
 * User: oinam
 * Date: 2/4/2016
 * Time: 4:08 PM
 */
class Application_Model_Teamplayer
{
    protected $_id;

    protected $_teamid;
    protected $_playerid;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * @param mixed $id
     * @return Application_Model_Teamplayer
     */
    public function setId($id)
    {
        $this->_id = $id;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getTeamid()
    {
        return $this->_teamid;
    }

    /**
     * @param mixed $teamid
     * @return Application_Model_Teamplayer
     */
    public function setTeamid($teamid)
    {
        $this->_teamid = $teamid;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPlayerid()
    {
        return $this->_playerid;
    }

    /**
     * @param mixed $playerid
     * @return Application_Model_Teamplayer
     */
    public function setPlayerid($playerid)
    {
        $this->_playerid = $playerid;
        return $this;
    }
}