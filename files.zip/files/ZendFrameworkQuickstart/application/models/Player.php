<?php

/**
 * Created by PhpStorm.
 * User: oinam
 * Date: 2/4/2016
 * Time: 4:08 PM
 */
class Application_Model_Player
{
    protected $_id;
    protected $_firstname;
    protected $_lastname;
    protected $_imageuri;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * @param mixed $id
     * @return Application_Model_Player
     */
    public function setId($id)
    {
        $this->_id = $id;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getFirstname()
    {
        return $this->_firstname;
    }

    /**
     * @param mixed $firstname
     * @return Application_Model_Player
     */
    public function setFirstname($firstname)
    {
        $this->_firstname = $firstname;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastname()
    {
        return $this->_lastname;
    }

    /**
     * @param mixed $lastname
     * @return Application_Model_Player
     */
    public function setLastname($lastname)
    {
        $this->_lastname = $lastname;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getImageuri()
    {
        return $this->_imageuri;
    }

    /**
     * @param mixed $imageuri
     * @return Application_Model_Player
     */
    public function setImageuri($imageuri)
    {
        $this->_imageuri = $imageuri;
        return $this;
    }

}