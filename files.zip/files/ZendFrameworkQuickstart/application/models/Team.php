<?php

/**
 * Created by PhpStorm.
 * User: oinam
 * Date: 2/4/2016
 * Time: 4:08 PM
 */
class Application_Model_Team
{
    protected $_id;
    protected $_logouri;
    protected $_name;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * @param mixed $id
     * @return Application_Model_Team
     */
    public function setId($id)
    {
        $this->_id = $id;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getLogouri()
    {
        return $this->_logouri;
    }

    /**
     * @param mixed $logouri
     */
    public function setLogouri($logouri)
    {
        $this->_logouri = $logouri;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->_name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->_name = $name;
        return $this;
    }

}