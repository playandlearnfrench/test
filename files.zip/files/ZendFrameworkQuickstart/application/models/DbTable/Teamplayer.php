<?php

class Application_Model_DbTable_Teamplayer extends Zend_Db_Table_Abstract
{
    protected $_name = 'tbl_team_player';
}
