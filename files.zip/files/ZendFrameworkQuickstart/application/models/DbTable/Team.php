<?php

class Application_Model_DbTable_Team extends Zend_Db_Table_Abstract
{
    protected $_name = 'tbl_team';
}
