<?php

class Application_Model_TeamplayerMapper
{
    protected $_dbTable;

    public function setDbTable($dbTable)
    {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception('Invalid table data gateway provided');
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    public function getDbTable()
    {
        if (null === $this->_dbTable) {
            $this->setDbTable('Application_Model_DbTable_Teamplayer');
        }
        return $this->_dbTable;
    }


    public function findById($id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = $db->select();
        $select->from('tbl_team_player')
                ->joinLeft(
                    'tbl_team','tbl_team_player.teamid = tbl_team.id',
                    array('tbl_team.id', 'tbl_team.name','tbl_team.logouri')
                )
            ->joinLeft(
                'tbl_player','tbl_player.id = tbl_team_player.playerid',
                array('playerid'=>'tbl_player.id', 'tbl_player.firstname','tbl_player.lastname','tbl_player.imageuri')
            )
            ->where('tbl_team.id = ?', $id);
        $resultSet = $db->fetchAll($select);

        $playerArray =array();
        $id=0;
        $logoUri='';
        $name='';
        foreach ($resultSet as $row) {
            $id=$row['id'];
            $logoUri=$row['logouri'];
            $name=$row['name'];
            $firstName=$row['firstname'];
            $lastName=$row['lastname'];
            $imageUri=$row['imageuri'];
            $playerId=$row['playerid'];

            $playerArray[] =array(
                'id'=> $playerId,
                'firstName'=>$firstName ,
                'lastName'=> $lastName,
                'imageUri'=> $imageUri
            );

        }
        $returnArray= array(
            'id'=> $id,
            'logoUri'=>$logoUri,
            'name'=> $name,
            'players'=>$playerArray
        );
        return $returnArray;
    }

}

