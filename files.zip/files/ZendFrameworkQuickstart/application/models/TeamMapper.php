<?php

class Application_Model_TeamMapper
{
    protected $_dbTable;

    public function setDbTable($dbTable)
    {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception('Invalid table data gateway provided');
        }
        $this->_dbTable = $dbTable;
        return $this;
    }

    public function getDbTable()
    {
        if (null === $this->_dbTable) {
            $this->setDbTable('Application_Model_DbTable_Team');
        }
        return $this->_dbTable;
    }

    public function save(Application_Model_Team $team)
    {
        $data = array(
            'name'   => $team->getName(),
            'logouri' => $team->getLogouri()
        );

        if (null === ($id = $team->getId())) {
            unset($data['id']);
            $this->getDbTable()->insert($data);
        } else {
            $this->getDbTable()->update($data, array('id = ?' => $id));
        }
    }

    public function find($id, Application_Model_Team $team)
    {
        $result = $this->getDbTable()->find($id);
        if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        $team->setId($row->id)
                  ->setLogouri($row->logouri)
                  ->setName($row->name);
    }

    public function fetchAll()
    {
        $resultSet = $this->getDbTable()->fetchAll();
        $entries   = array();
        foreach ($resultSet as $row) {
            $entry = new Application_Model_Team();
            $entry->setId($row->id)
                  ->setName($row->name)
                  ->setLogouri($row->logouri);
            $entries[] = $entry;
        }
        return $entries;
    }

    public function fetchArrayAll()
    {
        $select = $this->getDbTable()->select();
        $select->order('name');
        $resultSet = $this->getDbTable()->fetchAll($select);
        $entries   = array();
        foreach ($resultSet as $row) {
            $entries[] = array('id'=>$row->id,'name'=>$row->name,'logoUri'=>$row->logouri);
        }
        return $entries;
    }

}

