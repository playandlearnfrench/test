<?php

/**
 * Created by PhpStorm.
 * User: oinam
 * Date: 2/4/2016
 * Time: 3:08 PM
 */
class TeamController extends Zend_Rest_Controller
{
	public function preDispatch(){
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }
    public function init()
    {
       // $this->_helper->viewRenderer->setNoRender(true);		
		//$this->_helper->layout()->disableLayout();
    }

    /**
     * The index action handles index/list requests; it should respond with a
     * list of the requested resources.
     */
    public function indexAction()
    {
        //$this->getResponse()
         //   ->appendBody("From indexAction() returning all teams");
       $team = new Application_Model_TeamMapper();
       // $this->view->entries = $team->fetchAll();
        //var_dump($team->fetchAll());
        echo Zend_Json::encode(array('records'=>$team->fetchArrayAll()));
    }

    /**
     * The get action handles GET requests and receives an 'id' parameter; it
     * should respond with the server resource state of the resource identified
     * by the 'id' value.
     */
    public function getAction()
    {
        $id=$this->_getParam('id');
        $teamPlayer = new Application_Model_TeamplayerMapper();
        echo Zend_Json::encode(array('records'=>$teamPlayer->findById($id)));
    }

    /**
     * The head action handles HEAD requests and receives an 'id' parameter; it
     * should respond with the server resource state of the resource identified
     * by the 'id' value.
     */
    public function headAction()
    {
        $this->getResponse()->setBody(null);
    }

    /**
     * The post action handles POST requests; it should accept and digest a
     * POSTed resource representation and persist the resource state.
     */
    public function postAction()
    {
        $this->getResponse()->setBody(null);
        $this->getResponse()->setHeader('Allow', 'OPTIONS, HEAD, INDEX, GET, POST, PUT, DELETE');
    }

    /**
     * The put action handles PUT requests and receives an 'id' parameter; it
     * should update the server resource state of the resource identified by
     * the 'id' value.
     */
    public function putAction()
    {
        // TODO: Implement putAction() method.
    }

    /**
     * The delete action handles DELETE requests and receives an 'id'
     * parameter; it should update the server resource state of the resource
     * identified by the 'id' value.
     */
    public function deleteAction()
    {
        // TODO: Implement deleteAction() method.
    }
}