package com.sg.oinam.controller;

import static org.mockito.Mockito.*;
//import static org.testng.Assert.assertEquals;

//import org.testng.annotations.Test;
import org.junit.Test;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
 
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.sg.oinam.entity.Person;
import com.sg.oinam.service.IPersonService;

@RunWith(MockitoJUnitRunner.class)
public class StandalonePersonControllerTest {

	@Mock
    private IPersonService personService;

    @InjectMocks
    private PersonController personController;
    
//    @Spy
//    List<Person> personList = new ArrayList<Person>();
    
    @Spy
    ModelMap model;
     
    @Mock
    BindingResult result;
    
    public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
         MediaType.APPLICATION_JSON.getType(),
         MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
    
    @Before
    public void setUp() {
    	MockMvcBuilders.standaloneSetup(personController).build();
    }

    @Test
    public void listPerson() throws Exception{
    	List<Person> personList = getPersonList();    	
        when(personService.getAllPersons()).thenReturn(personList);
        personController.getAllPersons();
        
        //Assert.assertEquals(personController.getAllPersons(), "allemployees");
       // Assert.assertEquals(model.get("employees"), personList);
        verify(personService, atLeastOnce()).getAllPersons();
        //verify(personService, times(1)).getAllPersons();
        verifyNoMoreInteractions(personService);
    }
	public List<Person> getPersonList() {
		List<Person> personList = new ArrayList<Person>();
    	Person person= new Person();
    	person.setName("Oinam");
    	person.setPid(1);
    	person.setLocation("Imphal");
    	personList.add(person);
		Person person1= new Person();
    	person1.setName("Bembem");
    	person1.setPid(2);
    	person1.setLocation("Banashankari");
    	personList.add(person1);
    	return personList;
//    	Mockito.when(personService.getAllPersons()).thenReturn(listPerson);
//    	//List<Person> list = personController.getAllPersons();
//    	
//    	mockMvc.perform(get("/person"))
//        .andExpect(status().isOk())
//        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
//        .andExpect(jsonPath("$", Mockito.hasSize(2)))
//        .andExpect(jsonPath("$[0].id", Mockito.is(1)))
//        .andExpect(jsonPath("$[0].name", Mockito.is("Oinam")))
//        .andExpect(jsonPath("$[1].id", Mockito.is(2)))
//        .andExpect(jsonPath("$[1].name", Mockito.is("Bembem")));
//    	Mockito.verify(personService, Mockito.times(1)).getAllPersons();
    	
	}
    
}
