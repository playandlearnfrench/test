package com.sg.oinam.controller;

//import org.testng.annotations.Test;
import org.junit.Test;

import java.nio.charset.Charset;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sg.oinam.config.AppConfig;
import com.sg.oinam.entity.Person;
import com.sg.oinam.service.IPersonService;

import org.springframework.test.context.web.WebAppConfiguration;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ContextConfiguration(classes = {AppConfig.class}) //working only one is needed
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class PersonControllerTest {

	private MockMvc mockMvc;

    @Autowired
    private IPersonService personService;
    
    @Autowired
    private WebApplicationContext webApplicationContext;

        
    public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
            MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
    
    @Before
    public void setUp() {
 //   	MockitoAnnotations.initMocks(this);
    	//personController = new PersonController();
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .build();
    	//personList=getPersonList();
    }

    @Test	
    public void listPerson() throws Exception{
    //	MvcResult result = mockMvc.perform(get("/info/person").accept(MediaType.APPLICATION_JSON)).andReturn();
    // String content = result.getResponse().getContentAsString(); 
    	//works both ways
     //List<Person> personList = personService.getAllPersons();
    	mockMvc.perform(get("/info/person"))
      .andExpect(status().isOk())
      .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
   //   .andExpect(jsonPath("$", hasSize(3)));
//      .andExpect(jsonPath("$[0].id", Mockito.is(1)))
//      .andExpect(jsonPath("$[0].name", Mockito.is("Oinam")))
//      .andExpect(jsonPath("$[1].id", Mockito.is(2)))
//      .andExpect(jsonPath("$[1].name", Mockito.is("Bembem")));
    	//Mockito.verify(personService, Mockito.times(1)).getAllPersons();
    }
    @Test	
    public void addPerson() throws Exception{
    	Person person = new Person();
    	person.setName("Dhaksika Oinam");
    	person.setLocation("Bangalore");
    	//Boolean flag = true;
		//Mockito.when(personService.addPerson(Mockito.any(Person.class))).thenReturn(flag);
		//boolean flag = personService.addPerson(person);
//    	mockMvc.perform(post("/info/person"))
//      .andExpect(status().isOk())
//      .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
    	
		MvcResult result = mockMvc.perform(
                post("/info/person")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(person)))
                .andExpect(status().isCreated())
               // .andExpect(header().string("location", containsString("http://localhost/info/person/")))
                .andReturn();
                //.andExpect(header().string("location", containsString("http://localhost/info/person/")))
               // ;
		String content = result.getResponse().getContentAsString();
    }
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
