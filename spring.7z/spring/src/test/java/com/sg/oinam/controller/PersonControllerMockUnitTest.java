package com.sg.oinam.controller;

import static org.mockito.Mockito.*;
//import static org.testng.Assert.assertEquals;

//import org.testng.annotations.Test;
import org.junit.Test;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.context.WebApplicationContext;

import com.sg.oinam.controller.PersonController;
import com.sg.oinam.entity.Person;
import com.sg.oinam.service.IPersonService;

import org.springframework.test.context.web.WebAppConfiguration;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonControllerMockUnitTest {

	private MockMvc mockMvc;

    @Mock
    private IPersonService personService;

    @InjectMocks
    private PersonController personController;
    
    @Spy
    ModelMap model;
     
    @Mock
    BindingResult result;
    
    public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
            MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
    
    @Before
    public void setUp() {
    	MockitoAnnotations.initMocks(this); //works same as below
        this.mockMvc = MockMvcBuilders.standaloneSetup(personController).build();
    }

    @Test
    public void listPerson() throws Exception{
    	List<Person> personList = getPersonList();    	
        when(personService.getAllPersons()).thenReturn(personList);
        List<Person> result= personController.getAllPersons();
        assertTrue(result.equals(personList));
        //Assert.assertEquals(personList,personController.getAllPersons());
        verify(personService, atLeastOnce()).getAllPersons();
        //verify(personService, times(1)).getAllPersons();
        verifyNoMoreInteractions(personService);
    }
    
    @Test
    public void getAllPersons_ShouldReturnFoundPersonEntries() throws Exception{
    	List<Person> personList = getPersonList();    	
        when(personService.getAllPersons()).thenReturn(personList);
        
    	//MvcResult result = mockMvc.perform(get("/info/person").accept(MediaType.APPLICATION_JSON)).andReturn();
        //String content = result.getResponse().getContentAsString(); 
        
        mockMvc.perform(get("/info/person"))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        .andExpect(jsonPath("$", hasSize(2)))
        .andExpect(jsonPath("$[0].pid", is(1)))
        .andExpect(jsonPath("$[0].name", is("Oinam")))
        .andExpect(jsonPath("$[0].location", is("Imphal")))
        .andExpect(jsonPath("$[1].pid", is(2)))
        .andExpect(jsonPath("$[1].name", is("Bembem")))
        .andExpect(jsonPath("$[1].location", is("Banashankari")));
        verify(personService, atLeastOnce()).getAllPersons();
        verifyNoMoreInteractions(personService);
    }
    
	public List<Person> getPersonList() {
		List<Person> personList = new ArrayList<Person>();
    	Person person= new Person();
    	person.setName("Oinam");
    	person.setPid(1);
    	person.setLocation("Imphal");
    	personList.add(person);
		Person person1= new Person();
    	person1.setName("Bembem");
    	person1.setPid(2);
    	person1.setLocation("Banashankari");
    	personList.add(person1);
    	return personList;
	}
    
}
