package com.sg.oinam.dao;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.sg.oinam.config.AppConfig;
import com.sg.oinam.dao.IPersonDAO;
import com.sg.oinam.entity.Person;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {AppConfig.class})
@WebAppConfiguration
public class PersonDAOTest {
	
	//private EmbeddedDatabase db;
	
	@Autowired
	IPersonDAO personDAO;
	
	@Before
    public void setUp() {
        //db = new EmbeddedDatabaseBuilder().addDefaultScripts().build();
    	/*db = new EmbeddedDatabaseBuilder()
    		.setType(EmbeddedDatabaseType.H2)
    		.addScript("schema.sql")
    		.addScript("data.sql")
    		.build();*/
    }

    @Test
    public void testFindByname() {
    	//NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(db);
    	assertTrue(personDAO.personExists("Oinam Singh", "Bangalore"));
    }
    
    @Test
    public void testAddPerson() {
    	//NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(db);
    	Person person = new Person();
    	person.setName("Dhaksika Oinam");
    	person.setLocation("Bangalore");
    	personDAO.addPerson(person);
    	System.out.println(personDAO.getAllPersons().size());
    }
    
    @Test
    public void testGetAllPersons() {
    	List<Person> listPersons = personDAO.getAllPersons();
    	//System.out.println(listPersons.size());
    }

    @After
    public void tearDown() {
      //  db.shutdown();
    }
}
