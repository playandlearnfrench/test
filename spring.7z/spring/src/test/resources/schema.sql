CREATE TABLE if not exists person (
  pid number NOT NULL auto_increment primary key,
  name varchar(100) NOT NULL unique,
  location varchar(100) NOT NULL
);

CREATE SEQUENCE PERSON_SEQ_ID;