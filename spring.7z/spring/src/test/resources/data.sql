INSERT INTO person (pid, name, location) VALUES (PERSON_SEQ_ID.NEXTVAL, 'Oinam Singh', 'Bangalore');
INSERT INTO person (pid, name, location) VALUES (PERSON_SEQ_ID.NEXTVAL, 'Amit Singh', 'Delhi');
INSERT INTO person (pid, name, location) VALUES (PERSON_SEQ_ID.NEXTVAL, 'Sonam Kapoor', 'Mumbai');