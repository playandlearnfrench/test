import React from "react";

class About extends React.Component {
  render() {
    return (
      <div>
        <h1>About...</h1>
        <object
          width="100%"
          height="400"
          data="http://www.africau.edu/images/default/sample.pdf"
          type="application/pdf"
        >
          {" "}
        </object>
      </div>
    );
  }
}
export default About;
