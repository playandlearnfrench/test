import React from "react";

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = { size: 100 };
    this.boxRef = React.createRef();
  }

  handleIncrementClick = () => {
    // set new state to force update
    this.setState((state, props) => ({ size: state.size + 10 }));
  };

  componentDidUpdate(prevState, prevProps) {
    // react to update and change the HTML element's size
    this.boxRef.current.style.width = `${this.state.size}px`;
    this.boxRef.current.style.height = `${this.state.size}px`;
  }
  render() {
    return (
      <div>
        <h1>Home...</h1>
        <button onClick={this.handleIncrementClick}>Resize</button>
        <div ref={this.boxRef}></div>
      </div>
    );
  }
}
export default Home;
