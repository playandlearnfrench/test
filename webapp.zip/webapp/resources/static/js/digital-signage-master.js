/* digital-signage-master ui */

(function() {
  var API, App,  Asset, Assets, AssetMaster, AssetRowView, AssetMasterRowView, AssetsMaster, AssetsMasterView, EditAssetView, date_settings, date_settings_12hour, date_settings_24hour, date_to, delay, get_template, insertWbr, now, url_test, viduris,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; },
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty,
    slice = [].slice;

  API = (window.DigitalSignageMaster || (window.DigitalSignageMaster = {}));
  
  date_settings_12hour = {
    full_date: 'MM/DD/YYYY hh:mm:ss A',
    date: 'MM/DD/YYYY',
    time: 'hh:mm A',
    show_meridian: true,
    date_picker_format: 'mm/dd/yyyy'
  };

  date_settings_24hour = {
    full_date: 'MM/DD/YYYY HH:mm:ss',
    date: 'MM/DD/YYYY',
    time: 'HH:mm',
    show_meridian: false,
    datepicker_format: 'mm/dd/yyyy'
  };

  date_settings = use_24_hour_clock ? date_settings_24hour : date_settings_12hour;

  API.date_to = date_to = function(d) {
    var dd;
    dd = moment(new Date(d));
    return {
      string: function() {
        return dd.format(date_settings.full_date);
      },
      date: function() {
        return dd.format(date_settings.date);
      },
      time: function() {
        return dd.format(date_settings.time);
      }
    };
  };
  now = function() {
    return new Date();
  };
  get_template = function(name) {
    return _.template(($("#" + name + "-template")).html());
  };

  delay = function(wait, fn) {
    return _.delay(fn, wait);
  };
 
  mimetypes = [['jpg jpeg png pnm gif bmp'.split(' '), 'image'], ['avi mkv mov mpg mpeg mp4 ts flv'.split(' '), 'video']];

  viduris = 'rtsp rtmp'.split(' ');

  get_mimetype = (function(_this) {
    return function(filename) {
      var ext, match, mt, scheme;
      scheme = (_.first(filename.split(':'))).toLowerCase();
      match = indexOf.call(viduris, scheme) >= 0;
      if (match) {
        return 'video';
      }
      ext = (_.last(filename.split('.'))).toLowerCase();
      mt = _.find(mimetypes, function(mt) {
        return indexOf.call(mt[0], ext) >= 0;
      });
      if (mt) {
        return mt[1];
      } else {
        return null;
      }
    };
  })(this);

  url_test = function(v) {
    return /(http|https|rtsp|rtmp):\/\/[\w-]+(\.?[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/.test(v);
  };

  get_filename = function(v) {
    return (v.replace(/[\/\\\s]+$/g, '')).replace(/^.*[\\\/]/g, '');
  };
  
  insertWbr = function(v) {
    return (v.replace(/\//g, '/<wbr>')).replace(/\&/g, '&amp;<wbr>');
  };

  Backbone.emulateJSON = true;

  API.AssetMaster = AssetMaster = (function(superClass) {
    extend(AssetMaster, superClass);

    function AssetMaster() {
    	this.old_name = bind(this.old_name, this);
    	this.rollback = bind(this.rollback, this);
    	this.backup = bind(this.backup, this);
    	this.active = bind(this.active, this);
    	this.defaults = bind(this.defaults, this);
    	return AssetMaster.__super__.constructor.apply(this, arguments);
    }

    AssetMaster.prototype.idAttribute = "id";

    AssetMaster.prototype.fields = 'name ipAddress'.split(' ');

    AssetMaster.prototype.defaults = function() {
      return {
        name: '',
        ip_address: ''
       // ,is_active: false     
      //  ,enabled: 0
      };
    };

    AssetMaster.prototype.active = function() {
    	//return this.get('enabled');
    	return true;
    };
   
    AssetMaster.prototype.old_name = function() {
      if (this.backup_attributes) {
        return this.backup_attributes.name;
      }
    };

    return AssetMaster;

  })(Backbone.Model);

  API.AssetsMaster = AssetsMaster = (function(superClass) {
    extend(AssetsMaster, superClass);

    function AssetsMaster() {
      return AssetsMaster.__super__.constructor.apply(this, arguments);
    }

    AssetsMaster.prototype.url = "api/raspBerryPi";

    AssetsMaster.prototype.model = AssetMaster;

    AssetsMaster.prototype.comparator = 'ipAddress';

    return AssetsMaster;

  })(Backbone.Collection);

  API.Asset = Asset = (function(superClass) {
    extend(Asset, superClass);

    function Asset() {
      this.old_name = bind(this.old_name, this);
      this.rollback = bind(this.rollback, this);
      this.backup = bind(this.backup, this);
      this.active = bind(this.active, this);
      this.defaults = bind(this.defaults, this);
      return Asset.__super__.constructor.apply(this, arguments);
    }

    Asset.prototype.idAttribute = "asset_id";

    //Asset.prototype.fields = 'name mimetype uri start_date end_date duration ip_address selectedIpAddress'.split(' ');

    Asset.prototype.fields = 'name mimetype start_date end_date duration ip_address selectedIpAddress'.split(' ');

    Asset.prototype.defaults = function() {
      return {
        name: '',
        mimetype: 'video',
        uri: '',
        is_active: false,
        start_date: now(),
        end_date: (moment().add('days', 7)).toDate(),
        duration: default_duration,
        is_enabled: 0,
        nocache: 0,
        play_order: 0,
        ip_address: '',
        selectedIpAddress:''
      };
    };
    
    Asset.prototype.active = function() {
      var at, end_date, start_date;
      if (this.get('is_enabled') && this.get('start_date') && this.get('end_date')) {
        at = now();
        start_date = new Date(this.get('start_date'));
        end_date = new Date(this.get('end_date'));
        return (start_date <= at && at <= end_date);
      } else {
        return false;
      }
    };

    Asset.prototype.backup = function() {
      return this.backup_attributes = this.toJSON();
    };

    Asset.prototype.rollback = function() {
      if (this.backup_attributes) {
        this.set(this.backup_attributes);
        return this.backup_attributes = void 0;
      }
    };

    Asset.prototype.old_name = function() {
      if (this.backup_attributes) {
        return this.backup_attributes.name;
      }
    };

    return Asset;

  })(Backbone.Model);

  API.Assets = Assets = (function(superClass) {
    extend(Assets, superClass);

    function Assets() {
      return Assets.__super__.constructor.apply(this, arguments);
    }

    Assets.prototype.url = "api/assets";

    Assets.prototype.model = Asset;

    Assets.prototype.comparator = 'play_order';

    return Assets;

  })(Backbone.Collection);
  API.View = {};

  API.View.AssetMasterRowView = AssetMasterRowView = (function(superClass) {
    extend(AssetMasterRowView, superClass);

    function AssetMasterRowView() {
     // this.edit = bind(this.edit, this);
      this.render = bind(this.render, this);
      this.initialize = bind(this.initialize, this);
      return AssetMasterRowView.__super__.constructor.apply(this, arguments);
    }

    AssetMasterRowView.prototype.tagName = "tr";

    AssetMasterRowView.prototype.initialize = function(options) {
      return this.template = get_template('asset-master-row');
    };

    AssetMasterRowView.prototype.render = function() {
      var json;
      this.$el.html(this.template(_.extend(json = this.model.toJSON(), {
        name: insertWbr(json.name)       
      })));
      this.$el.prop('id', this.model.get('id'));      
      (this.$(".toggle input")).prop("checked", this.model.get('enabled'));
      return this.el;
    };
    
    AssetMasterRowView.prototype.events = {    	      
      'click .view-asset-button': 'view',
      'change': 'change',
      'keyup': 'change'
    };
    
    AssetMasterRowView.prototype.view = function(e) {    	
    	//window.location = "http://localhost:8080/digitalsignage/home";
    	//window.location = "http://localhost:8080/digitalsignage/home?ipAddress="+this.model.get('ipAddress');
    	$( "#assetsMaster").hide();
    	$( "#assets").show();
    	if ($('#add-asset-button').hasClass('disabled')) {
    		$('#add-asset-button').removeClass('disabled');  
   	  	}
    	var ipAddress = this.model.get('ipAddress');
    	(API.assets = new Assets()).fetch({    	       
    	       data: { ipAddress: ipAddress },
    	       postData: true,
    	       success: function(){
    	    	   API.assetsView = new AssetsView({
    	               collection: API.assets,
    	               el: this.$('#assets')
    	            });
    	       },
    	       error: function(){}
    	  });    	
        
        return false;
      };
      
      AssetMasterRowView.prototype.change = function(e) {
          var checkLength = $( "#active-raspberry input:checked" ).length;
          if(checkLength>0){
        	  if ($('#add-asset-button').hasClass('disabled')) {
        		 $('#add-asset-button').removeClass('disabled');  
        	  }
        	  //$(".container .add").prop('disabled',false);
          }else {
        	  if (!$('#add-asset-button').hasClass('disabled')) {
        		  $('#add-asset-button').addClass('disabled');  
        	  }
        	//  $(".container .add").prop('disabled',true);
          }          
          return true;
      };
      
    return AssetMasterRowView;

  })(Backbone.View);
  
   API.View.AssetRowView = AssetRowView = (function(superClass) {
    extend(AssetRowView, superClass);

    function AssetRowView() {
      this.hidePopover = bind(this.hidePopover, this);
      this.showPopover = bind(this.showPopover, this);
      this["delete"] = bind(this["delete"], this);
      this.edit = bind(this.edit, this);
      this.render = bind(this.render, this);
      this.initialize = bind(this.initialize, this);
      return AssetRowView.__super__.constructor.apply(this, arguments);
    }

    AssetRowView.prototype.tagName = "tr";

    AssetRowView.prototype.initialize = function(options) {
      return this.template = get_template('asset-row');
    };

    AssetRowView.prototype.render = function() {
      var json;      
      this.$el.html(this.template(_.extend(json = this.model.toJSON(), {
          name: insertWbr(json.name),
          start_date: (date_to(json.start_date)).string(),
          end_date: (date_to(json.end_date)).string()
        })));
      this.$el.prop('id', this.model.get('id'));
     // this.$el.prop("id", this.model.get('id')+'_'+this.model.get('ip_address'));
      (this.$(".delete-asset-button")).popover({
          content: get_template('confirm-delete')
        });
      (this.$(".toggle input")).prop("checked", this.model.get('is_enabled'));
      (this.$(".asset-icon")).addClass((function() {
          switch (this.model.get("mimetype")) {
            case "video":
              return "glyphicon glyphicon-facetime-video";
            case "image":
              return "glyphicon glyphicon-picture";
            case "webpage":
              return "glyphicon glyphicon-globe";
            default:
              return "";
          }
        }).call(this));
      return this.el;
    };
    
    AssetRowView.prototype.events = {    	      
		'change .is_enabled-toggle input': 'toggleIsEnabled',
		'click .delete-asset-button': 'showPopover'	
    };
    
    AssetRowView.prototype.toggleIsEnabled = function(e) {
    	//console.log(this.model.get('ip_address'));
    	this.model.set({selectedIpAddress:this.model.get('ip_address')});
        var save, val;
        val = (1 + this.model.get('is_enabled')) % 2;
        this.model.set({
          is_enabled: val
        });
        this.setEnabled(false);
        save = this.model.save();
        save.done((function(_this) {
          return function() {
            return _this.setEnabled(true);
          };
        })(this));
        save.fail((function(_this) {
          return function() {
            _this.model.set(_this.model.previousAttributes(), {
              silent: true
            });
            _this.setEnabled(true);
            return _this.render();
          };
        })(this));
        return true;
      };
      
      AssetRowView.prototype.setEnabled = function(enabled) {
          if (enabled) {
            this.$el.removeClass('warning');
            this.delegateEvents();
            return (this.$('input, button')).prop('disabled', false);
          } else {
            this.hidePopover();
            this.undelegateEvents();
            this.$el.addClass('warning');
            return (this.$('input, button')).prop('disabled', true);
          }
        };
      
      AssetRowView.prototype["delete"] = function(e) {
          var xhr;
          this.hidePopover();
          if ((xhr = this.model.destroy()) === !false) {
            xhr.done((function(_this) {
              return function() {
                return _this.remove();
              };
            })(this));
          } else {
            this.remove();
          }
          return false;
        };
        
      AssetRowView.prototype.showPopover = function() {
          if (!($('.popover')).length) {
            (this.$(".delete-asset-button")).popover('show');
            ($('.confirm-delete')).click(this["delete"]);
            ($(window)).one('click', this.hidePopover);
          }
          return false;
        };

        AssetRowView.prototype.hidePopover = function() {
          (this.$(".delete-asset-button")).popover('hide');
          return false;
        };
        
    return AssetRowView;

  })(Backbone.View);

  API.View.AssetsMasterView = AssetsMasterView = (function(superClass) {
    extend(AssetsMasterView, superClass);

    function AssetsMasterView() {
      this.render = bind(this.render, this);
      this.initialize = bind(this.initialize, this);
      return AssetsMasterView.__super__.constructor.apply(this, arguments);
    }

    AssetsMasterView.prototype.initialize = function(options) {
      var event, k, len, ref;
      ref = 'reset add remove sync'.split(' ');
      for (k = 0, len = ref.length; k < len; k++) {
        event = ref[k];
        this.collection.bind(event, this.render);
      }      
    };   

    AssetsMasterView.prototype.render = function() {
      var k, l, len, len1, ref, ref1, which;
      ref = ['active'];
      for (k = 0, len = ref.length; k < len; k++) {
        which = ref[k];
        (this.$("#" + which + "-raspberry")).html('');
      }
      this.collection.each((function(_this) {
        return function(model) {
          which ='active';
          return (_this.$("#" + which + "-raspberry")).append((new AssetMasterRowView({
            model: model
          })).render());
        };
      })(this));
      ref1 = ['active'];
      for (l = 0, len1 = ref1.length; l < len1; l++) {
        which = ref1[l];
        this.$("." + which + "-table thead").toggle(!!(this.$("#" + which + "-raspberry tr").length));
      }      
      return this.el;
    };

    return AssetsMasterView;

  })(Backbone.View);

  API.View.AssetsView = AssetsView = (function(superClass) {
    extend(AssetsView, superClass);

    function AssetsView() {
      this.render = bind(this.render, this);
      this.update_order = bind(this.update_order, this);
      this.initialize = bind(this.initialize, this);
      return AssetsView.__super__.constructor.apply(this, arguments);
    }

    AssetsView.prototype.initialize = function(options) {
      var event, k, len, ref;
      ref = 'reset add remove sync'.split(' ');
      for (k = 0, len = ref.length; k < len; k++) {
        event = ref[k];
        this.collection.bind(event, this.render);
      }
      return this.sorted = (this.$('#active-assets')).sortable({
        containment: 'parent',
        axis: 'y',
        helper: 'clone'
        //,update: this.update_order
      });
    };

    AssetsView.prototype.update_order = function() {
      var i, id, k, len, ref;
      ref = (this.$('#active-assets')).sortable('toArray');
      for (i = k = 0, len = ref.length; k < len; i = ++k) {
        id = ref[i];
        //this.collection.get(id).set('play_order', i);
      }
      this.collection.sort();
      return $.post('api/assets/order', {
        ids: ((this.$('#active-assets')).sortable('toArray')).join(',')
      });
    };

    AssetsView.prototype.render = function() {
      var k, l, len, len1, ref, ref1, which;
      ref = ['active', 'inactive'];
      for (k = 0, len = ref.length; k < len; k++) {
        which = ref[k];
        (this.$("#" + which + "-assets")).html('');
      }
      this.collection.each((function(_this) {
        return function(model) {
          which = model.active() ? 'active' : 'inactive';
          return (_this.$("#" + which + "-assets")).append((new AssetRowView({
            model: model
          })).render());
        };
      })(this));
      ref1 = ['inactive', 'active'];
      for (l = 0, len1 = ref1.length; l < len1; l++) {
        which = ref1[l];
        this.$("." + which + "-table thead").toggle(!!(this.$("#" + which + "-assets tr").length));
      }
      if (this.$('#active-assets tr').length > 1) {
        this.sorted.sortable('enable');
        //this.update_order();
      } else {
        this.sorted.sortable('disable');
      }
      return this.el;
    };

    return AssetsView;

  })(Backbone.View);
  
  API.App = App = (function(superClass) {
    extend(App, superClass);

    function App() {
      this.add = bind(this.add, this);
      this.initialize = bind(this.initialize, this);
      return App.__super__.constructor.apply(this, arguments);
    }

    App.prototype.initialize = function() {
      ($(window)).ajaxError((function(_this) {
        return function(e, r) {
          var err, j;
          ($('#request-error')).html((get_template('request-error'))());
          if ((j = $.parseJSON(r.responseText)) && (err = j.error)) {
            return ($('#request-error .msg')).text('Server Error: ' + err);
          }
        };
      })(this));
      ($(window)).ajaxSuccess((function(_this) {
        return function(data) {
          return ($('#request-error')).html('');
        };
      })(this));
//      (API.assets = new Assets()).fetch();
//       API.assetsView = new AssetsView({
//          collection: API.assets,
//          el: this.$('#assets')
//       });
      (API.assetsMaster = new AssetsMaster()).fetch();
      return API.AssetsMasterView = new AssetsMasterView({
        collection: API.assetsMaster,
        el: this.$('#assetsMaster')
      });      
      
    };

    App.prototype.events = {
      'click #add-asset-button': 'add'
    };

    App.prototype.add = function(e) {    	
    	if ((this.$('#add-asset-button')).hasClass('disabled')) {
    		return false;
    	}
      new EditAssetView({
        model: new Asset({}, {
          collection: API.assets
        })
      });
      return false;
    };
    	    
    return App;

  })(Backbone.View);

  API.View.EditAssetView = EditAssetView = (function(superClass) {
    extend(EditAssetView, superClass);

    function EditAssetView() {
     // this.displayAdvanced = bind(this.displayAdvanced, this);
     // this.toggleAdvanced = bind(this.toggleAdvanced, this);
      this.updateMimetype = bind(this.updateMimetype, this);
      this.updateFileUploadMimetype = bind(this.updateFileUploadMimetype, this);
      //this.updateUriMimetype = bind(this.updateUriMimetype, this);
      //this.clickTabNavUpload = bind(this.clickTabNavUpload, this);
     // this.clickTabNavUri = bind(this.clickTabNavUri, this);
      this.cancel = bind(this.cancel, this);
      this.validate = bind(this.validate, this);
      this.change_mimetype = bind(this.change_mimetype, this);
      this.change = bind(this.change, this);
      this.save = bind(this.save, this);
      this.viewmodel = bind(this.viewmodel, this);
      this.render = bind(this.render, this);
      this.initialize = bind(this.initialize, this);
      this.$fv = bind(this.$fv, this);
      this.$f = bind(this.$f, this);
      return EditAssetView.__super__.constructor.apply(this, arguments);
    }

    EditAssetView.prototype.$f = function(field) {
      return this.$("[name='" + field + "']");
    };

    EditAssetView.prototype.$fv = function() {
      var field, ref, val;
      field = arguments[0], val = 2 <= arguments.length ? slice.call(arguments, 1) : [];
      return (ref = this.$f(field)).val.apply(ref, val);
    };

    EditAssetView.prototype.initialize = function(options) {
      this.edit = options.edit;
      ($('body')).append(this.$el.html(get_template('asset-modal')));
      (this.$('input.time')).timepicker({
        minuteStep: 5,
        showInputs: true,
        disableFocus: true,
        showMeridian: date_settings.show_meridian
      });
     // (this.$('input[name="nocache"]')).prop('checked', this.model.get('nocache'));
      (this.$('.modal-header .close')).remove();
      (this.$el.children(":first")).modal();
      this.model.backup();
      this.model.bind('change', this.render);
      this.render();
      this.validate();
      _.delay(((function(_this) {
        return function() {
          return (_this.$f('file_upload')).focus();
        };
      })(this)), 300);
      return false;
    };

    EditAssetView.prototype.render = function() {
      var d, f, field, k, l, len, len1, len2, m, ref, ref1, ref2, which;
      this.undelegateEvents();
      if (this.edit) {
        //ref = 'mimetype uri file_upload'.split(' ');
        ref = 'mimetype file_upload'.split(' ');
        for (k = 0, len = ref.length; k < len; k++) {
          f = ref[k];
          (this.$(f)).attr('disabled', true);
        }
        (this.$('#modalLabel')).text("Edit Asset");
        (this.$('.asset-location')).hide();
        (this.$('.asset-location.edit')).show();
      }
     // (this.$('.duration')).hide();
      (this.$('.mimetype')).hide();
      
      ref1 = this.model.fields;
      for (l = 0, len1 = ref1.length; l < len1; l++) {
        field = ref1[l];
        if ((this.$fv(field)) !== this.model.get(field)) {
          this.$fv(field, this.model.get(field));
        }
      }
     // (this.$('.uri-text')).html(insertWbr(this.model.get('uri')));
      ref2 = ['start', 'end'];
      for (m = 0, len2 = ref2.length; m < len2; m++) {
        which = ref2[m];
        d = date_to(this.model.get(which + "_date"));
        this.$fv(which + "_date_date", d.date());
        (this.$f(which + "_date_date")).datepicker({
          autoclose: true,
          format: date_settings.datepicker_format
        });
        (this.$f(which + "_date_date")).datepicker('setValue', d.date());
        this.$fv(which + "_date_time", d.time());
      }
      var selectedIps=new Array();
      $( "#active-raspberry input:checked" ).each(function( index ) {        	
    	  selectedIps.push($( this ).val());
      });
      this.$fv("selectedIpAddress", selectedIps);
     // this.displayAdvanced();
      this.delegateEvents();
      return false;
    };

    EditAssetView.prototype.viewmodel = function() {
      var field, k, l, len, len1, ref, ref1, results, which;
      ref = ['start', 'end'];
      for (k = 0, len = ref.length; k < len; k++) {
        which = ref[k];
        this.$fv(which + "_date", (new Date((this.$fv(which + "_date_date")) + " " + (this.$fv(which + "_date_time")))).toISOString());
      }
      ref1 = this.model.fields;
      results = [];
      for (l = 0, len1 = ref1.length; l < len1; l++) {
        field = ref1[l];
        if (!(this.$f(field)).prop('disabled')) {
          results.push(this.model.set(field, this.$fv(field), {
            silent: true
          }));
        }
      //  console.log(field+' = '+this.$fv(field));
      }
      return results;
    };

    EditAssetView.prototype.events = {
      'submit form': 'save',
      'click .cancel': 'cancel',
      'change': 'change',
      'keyup': 'change',
      //'click .tabnav-uri': 'clickTabNavUri',
     // 'click .tabnav-file_upload': 'clickTabNavUpload',
     // 'click .tabnav-file_upload, .tabnav-uri': 'displayAdvanced',
     // 'click .advanced-toggle': 'toggleAdvanced',
     // 'paste [name=uri]': 'updateUriMimetype',
      'change [name=file_upload]': 'updateFileUploadMimetype',
      'change [name=mimetype]': 'change_mimetype'
    };

   /* EditAssetView.prototype.save = function(e) {
    	//console.log(this.model.url());    	
    	e.preventDefault();
    	return false;
    };*/
    EditAssetView.prototype.save = function(e) {
      var save;
      e.preventDefault();
      this.viewmodel();
     // this.viewmodel().save({ url: "api/assets" });
      save = null;
      this.model.set('nocache', (this.$('input[name="nocache"]')).prop('checked') ? 1 : 0);
      if ((this.$('#tab-file_upload')).hasClass('active')) {
        if (!this.$fv('name')) {
          this.$fv('name', get_filename(this.$fv('file_upload')));
        }
        (this.$('.progress')).show();
        this.$el.fileupload({
          //url: this.model.url(),
          url: 'api/assets',
          progressall: (function(_this) {
            return function(e, data) {
              if (data.loaded && data.total) {
                return (_this.$('.progress .bar')).css('width', (data.loaded / data.total * 100) + "%");
              }
            };
          })(this)
        });
        save = this.$el.fileupload('send', {
          fileInput: this.$f('file_upload')
        });
      } else {
        if (!this.model.get('name')) {
          if (this.model.old_name()) {
            this.model.set({
              name: this.model.old_name()
            }, {
              silent: true
            });
          } 
        }
        save = this.model.save();
      }
      (this.$('input, select')).prop('disabled', true);
      save.done((function(_this) {
        return function(data) {
          //_this.model.id = data.asset_id;
          if (!_this.model.collection) {
           // _this.collection.add(_this.model);
          }
          (_this.$el.children(":first")).modal('hide');
          _.extend(_this.model.attributes, data);
          if (!_this.edit) {
            //return _this.model.collection.add(_this.model);
            return true;
          }
        };
      })(this));
      save.fail((function(_this) {
        return function() {
          (_this.$('.progress')).hide();
          return (_this.$('input, select')).prop('disabled', false);
        };
      })(this));
      return false;
    };

    EditAssetView.prototype.change = function(e) {
      this._change || (this._change = _.throttle(((function(_this) {
        return function() {
          _this.viewmodel();
          _this.model.trigger('change');
          _this.validate();
          return true;
        };
      })(this)), 500));
      return this._change.apply(this, arguments);
    };

    EditAssetView.prototype.change_mimetype = function(duration) {
      //if ((this.$fv('mimetype')) !== "video") {
      if ((this.$fv('mimetype')) == "video") {
       // (this.$('.zerohint')).hide();
        //return this.$fv('duration', default_duration);
        //(this.$('.duration')).prop("readonly",false);
        (this.$('.duration')).hide();
        return this.$fv('duration', duration);
      }else  if ((this.$fv('mimetype')) == "image") {
    	  (this.$('.duration')).show();
          return this.$fv('duration', duration);
      }
      else {
    	(this.$('.duration')).hide();
        return this.$fv('duration', duration);
      }
    };

    EditAssetView.prototype.validate = function(e) {
      var errors, field, fn, k, len, ref, results, that, v, validators;
      that = this;
      validators = {
        duration: (function(_this) {
          return function(v) {
            if (('video' !== _this.model.get('mimetype')) && (!(_.isNumber(v * 1)) || v * 1 < 1)) {
              return 'please enter a valid number';
            }
          };
        })(this),        
        file_upload: (function(_this) {
          return function(v) {
            if (_this.model.isNew() && !v) {
              return 'please select a file';
            }
          };
        })(this),
        end_date: (function(_this) {
          return function(v) {
            if (!((new Date(_this.$fv('start_date'))) < (new Date(_this.$fv('end_date'))))) {
              return 'end date should be after start date';
            }
          };
        })(this)
      };
      errors = (function() {
        var results;
        results = [];
        for (field in validators) {
          fn = validators[field];
          if (v = fn(this.$fv(field))) {
            results.push([field, v]);
          }
        }
        return results;
      }).call(this);
      (this.$(".form-group.control-group.warning .help-inline.warning")).remove();
      (this.$(".form-group.control-group")).removeClass('warning');
      (this.$('[type=submit]')).prop('disabled', false);
      results = [];
      for (k = 0, len = errors.length; k < len; k++) {
        ref = errors[k], field = ref[0], v = ref[1];
        (this.$('[type=submit]')).prop('disabled', true);
        (this.$(".form-group.control-group." + field)).addClass('warning');
        //results.push((this.$(".control-group." + field + " .controls")).append($("<span class='help-inline warning'>" + v + "</span>")));
        results.push((this.$(".form-group.control-group." + field + " .newcontrols")).append($("<span class='help-inline warning'>" + v + "</span>")));
      }
      return results;
    };

    EditAssetView.prototype.cancel = function(e) {
      this.model.rollback();
      if (!this.edit) {
        this.model.destroy();
      }
      return (this.$el.children(":first")).modal('hide');
    };
   
    EditAssetView.prototype.updateFileUploadMimetype = function(e) {
      return _.defer((function(_this) {
        return function() {
        	var duration = default_duration;
        	if(get_mimetype(_this.$fv('file_upload'))=="video"){
        		var files = e.target.files;
        		var myVideos = [];
        		myVideos.push(files[0]);        		
        		var video = document.createElement('video');
        		video.src = URL.createObjectURL(files[0]);
        		video.onloadedmetadata = function() {
        			window.URL.revokeObjectURL(this.src);
        			duration = parseInt(video.duration);
        			return _this.updateMimetype(_this.$fv('file_upload'),duration);
        		}        		
        	}else{
        		return _this.updateMimetype(_this.$fv('file_upload'),duration);
        	}
        };
      })(this));
    };

    EditAssetView.prototype.updateMimetype = function(filename,duration) {
      var mt;
      mt = get_mimetype(filename);//console.log('file ext '+mt);
      (this.$('#file_upload_label')).text(get_filename(filename));
      if (mt) {
        this.$fv('mimetype', mt);
        (this.$('#file_upload_label')).css({"color": "#000"});
        //(this.$(".form-group.control-group.file_upload")).removeClass('has-error');        
      }else{
    	  (this.$('#file_upload_label')).text('Unsupported file');
    	  (this.$('#file_upload_label')).css({"color": "#f00"});
    	  //(this.$(".form-group.control-group.file_upload")).addClass('has-error');
    	  (this.$('[type=submit]')).prop('disabled', true);
      }
      return this.change_mimetype(duration);
    };   

    return EditAssetView;

  })(Backbone.View);

}).call(this);

